﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBurgers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBurgers))
        Label1 = New Label()
        picPrime = New PictureBox()
        picVeggie = New PictureBox()
        Button2 = New Button()
        Button1 = New Button()
        btnExit = New Button()
        btnSelectMeal = New Button()
        lblInstructions = New Label()
        lblConfirmation = New Label()
        CType(picPrime, ComponentModel.ISupportInitialize).BeginInit()
        CType(picVeggie, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top
        Label1.AutoSize = True
        Label1.ImageAlign = ContentAlignment.TopCenter
        Label1.Location = New Point(530, 9)
        Label1.Name = "Label1"
        Label1.RightToLeft = RightToLeft.Yes
        Label1.Size = New Size(233, 25)
        Label1.TabIndex = 0
        Label1.Text = "Farm Burger Specials"
        Label1.TextAlign = ContentAlignment.TopCenter
        ' 
        ' picPrime
        ' 
        picPrime.Enabled = False
        picPrime.InitialImage = CType(resources.GetObject("picPrime.InitialImage"), Image)
        picPrime.Location = New Point(267, 281)
        picPrime.Name = "picPrime"
        picPrime.Size = New Size(260, 250)
        picPrime.TabIndex = 1
        picPrime.TabStop = False
        picPrime.Visible = False
        ' 
        ' picVeggie
        ' 
        picVeggie.Enabled = False
        picVeggie.InitialImage = CType(resources.GetObject("picVeggie.InitialImage"), Image)
        picVeggie.Location = New Point(845, 281)
        picVeggie.Name = "picVeggie"
        picVeggie.Size = New Size(260, 250)
        picVeggie.TabIndex = 2
        picVeggie.TabStop = False
        picVeggie.Visible = False
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(321, 537)
        Button2.Name = "Button2"
        Button2.Size = New Size(128, 35)
        Button2.TabIndex = 4
        Button2.Text = "Prime Beef"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(913, 537)
        Button1.Name = "Button1"
        Button1.Size = New Size(128, 35)
        Button1.TabIndex = 5
        Button1.Text = "Veggie"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnExit.Location = New Point(1276, 782)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(128, 35)
        btnExit.TabIndex = 6
        btnExit.Text = "Exit Window"
        btnExit.UseVisualStyleBackColor = True
        btnExit.Visible = False
        ' 
        ' btnSelectMeal
        ' 
        btnSelectMeal.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnSelectMeal.Location = New Point(618, 672)
        btnSelectMeal.Name = "btnSelectMeal"
        btnSelectMeal.Size = New Size(128, 35)
        btnSelectMeal.TabIndex = 7
        btnSelectMeal.Text = "Select Meal"
        btnSelectMeal.UseVisualStyleBackColor = True
        ' 
        ' lblInstructions
        ' 
        lblInstructions.AutoSize = True
        lblInstructions.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblInstructions.Location = New Point(545, 558)
        lblInstructions.Name = "lblInstructions"
        lblInstructions.Size = New Size(312, 14)
        lblInstructions.TabIndex = 8
        lblInstructions.Text = "Choose a burger and then click the Select Meal button."
        ' 
        ' lblConfirmation
        ' 
        lblConfirmation.AutoSize = True
        lblConfirmation.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblConfirmation.Location = New Point(618, 603)
        lblConfirmation.Name = "lblConfirmation"
        lblConfirmation.Size = New Size(148, 14)
        lblConfirmation.TabIndex = 9
        lblConfirmation.Text = "Enjoy your burger special!"
        lblConfirmation.Visible = False
        ' 
        ' frmBurgers
        ' 
        AutoScaleDimensions = New SizeF(13F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1456, 918)
        Controls.Add(lblConfirmation)
        Controls.Add(lblInstructions)
        Controls.Add(btnSelectMeal)
        Controls.Add(btnExit)
        Controls.Add(Button1)
        Controls.Add(Button2)
        Controls.Add(picVeggie)
        Controls.Add(picPrime)
        Controls.Add(Label1)
        Font = New Font("Tahoma", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Margin = New Padding(6, 5, 6, 5)
        Name = "frmBurgers"
        Text = "Farm Burger Specials"
        CType(picPrime, ComponentModel.ISupportInitialize).EndInit()
        CType(picVeggie, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents picPrime As PictureBox
    Friend WithEvents picVeggie As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnSelectMeal As Button
    Friend WithEvents lblInstructions As Label
    Friend WithEvents lblConfirmation As Label

End Class
