# Burger Specials

## Student Information
- **Name:** Harold Sanders Jr
- **Course:** GUI Development Spring 2025
- **Assignment:** GUI Development Assignments A3 & A4
- **Development Tools Used:** Visual Studio, Visual Basic

## Project Description
This Windows Classic Desktop application displays the burger specials for a restaurant named Farm Burger. The user can select one of two specials: Prime Beef or Veggie. After selection, an image of the chosen meal appears, and the user can confirm their selection. Once a meal is selected and confirmed, further selection is disabled, and the exit button becomes active.

## Features
- Display two burger options: **Prime Beef** and **Veggie**
- Show an image of the selected meal
- Confirm selection and disable further choices
- Exit application after selection

## Event Plan Overview
| **Object**       | **Event Trigger**                   | **Event Processing**                                  |
|-----------------|-----------------------------------|------------------------------------------------------|
| `btnPrime`      | User clicks the button           | Displays Prime Beef image, enables Select Meal      |
| `btnVeggie`     | User clicks the button           | Displays Veggie image, enables Select Meal         |
| `btnSelectMeal` | User clicks the button           | Confirms selection, disables burger buttons, enables Exit button |
| `btnExit`       | User clicks the button           | Closes the application                             |

## Deliverables
1. **Event Plan Document:** (`A3EventPlan.docx/.xlsx/.pdf`) detailing all interaction elements and their expected behavior.
2. **GUI Layout Files:** Project files demonstrating the interface layout in Visual Basic.
3. **README File:** This document, describing the project and any issues encountered.
4. **Fully Functional GUI Application (A4):** Implementing the GUI with all events and behaviors outlined in A3.

## Issues Encountered
- None
