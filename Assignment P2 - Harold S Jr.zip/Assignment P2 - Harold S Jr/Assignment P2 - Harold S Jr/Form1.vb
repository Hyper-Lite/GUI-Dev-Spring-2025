﻿Public Class Form1
    ' Constants for tax rates
    Private Const FICA_RATE As Double = 0.062  ' 6.2% FICA tax
    Private Const FEDERAL_TAX_RATE As Double = 0.12 ' 12% Federal Tax
    Private Const STATE_TAX_RATE As Double = 0.05 ' 5% State Tax

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub btnComputeTaxes_Click(sender As Object, e As EventArgs) Handles btnComputeTaxes.Click
        Dim grossPay As Double
        Dim fica As Double
        Dim federalTax As Double
        Dim stateTax As Double
        Dim netPay As Double

        ' Validate input
        If Not Double.TryParse(txtGrossPay.Text, grossPay) OrElse grossPay < 0 Then
            MessageBox.Show("Please enter a valid positive number for Gross Pay.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtGrossPay.Clear()
            txtGrossPay.Focus()
            Return
        End If

        ' Calculate taxes
        fica = grossPay * FICA_RATE
        federalTax = grossPay * FEDERAL_TAX_RATE
        stateTax = grossPay * STATE_TAX_RATE
        netPay = grossPay - (fica + federalTax + stateTax)

        ' Display results
        lblFica.Text = "FICA: " & fica.ToString("C2")
        lblFederalTax.Text = "Federal Tax: " & federalTax.ToString("C2")
        lblStateTax.Text = "State Tax: " & stateTax.ToString("C2")
        lblNetIncome.Text = netPay.ToString("C2")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtGrossPay.Clear()
        lblFica.Text = "FICA: "
        lblFederalTax.Text = "Federal Tax: "
        lblStateTax.Text = "State Tax: "
        lblNetIncome.Text = "$0.00"
        txtGrossPay.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub lblNetPay_Click(sender As Object, e As EventArgs) Handles lblNetIncome.Click

    End Sub
End Class
