﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        txtGrossPay = New TextBox()
        btnComputeTaxes = New Button()
        btnClear = New Button()
        btnExit = New Button()
        lblFica = New Label()
        lblStateTax = New Label()
        lblFederalTax = New Label()
        lblNetIncome = New Label()
        lblNetPayResult = New Label()
        Label4 = New Label()
        lblNetPay = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.payroll
        PictureBox1.Location = New Point(12, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(300, 150)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(318, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(245, 37)
        Label1.TabIndex = 1
        Label1.Text = "Payroll Calculator"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(350, 79)
        Label2.Name = "Label2"
        Label2.Size = New Size(178, 25)
        Label2.TabIndex = 2
        Label2.Text = "Payroll Calculation"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Times New Roman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(199, 175)
        Label3.Name = "Label3"
        Label3.Size = New Size(137, 21)
        Label3.TabIndex = 3
        Label3.Text = "Enter Gross Pay:"
        ' 
        ' txtGrossPay
        ' 
        txtGrossPay.Location = New Point(342, 173)
        txtGrossPay.Name = "txtGrossPay"
        txtGrossPay.Size = New Size(100, 23)
        txtGrossPay.TabIndex = 4
        ' 
        ' btnComputeTaxes
        ' 
        btnComputeTaxes.Location = New Point(82, 199)
        btnComputeTaxes.Name = "btnComputeTaxes"
        btnComputeTaxes.Size = New Size(120, 40)
        btnComputeTaxes.TabIndex = 5
        btnComputeTaxes.Text = "Compute Taxes"
        btnComputeTaxes.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(243, 199)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(120, 40)
        btnClear.TabIndex = 6
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(408, 199)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(120, 40)
        btnExit.TabIndex = 7
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' lblFica
        ' 
        lblFica.AutoSize = True
        lblFica.Location = New Point(137, 292)
        lblFica.Name = "lblFica"
        lblFica.Size = New Size(32, 15)
        lblFica.TabIndex = 8
        lblFica.Text = "FICA"
        ' 
        ' lblStateTax
        ' 
        lblStateTax.AutoSize = True
        lblStateTax.Location = New Point(455, 292)
        lblStateTax.Name = "lblStateTax"
        lblStateTax.Size = New Size(53, 15)
        lblStateTax.TabIndex = 9
        lblStateTax.Text = "State Tax"
        ' 
        ' lblFederalTax
        ' 
        lblFederalTax.AutoSize = True
        lblFederalTax.Location = New Point(271, 292)
        lblFederalTax.Name = "lblFederalTax"
        lblFederalTax.Size = New Size(65, 15)
        lblFederalTax.TabIndex = 10
        lblFederalTax.Text = "Federal Tax"
        ' 
        ' lblNetIncome
        ' 
        lblNetIncome.AutoSize = True
        lblNetIncome.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblNetIncome.Location = New Point(384, 363)
        lblNetIncome.Name = "lblNetIncome"
        lblNetIncome.Size = New Size(14, 21)
        lblNetIncome.TabIndex = 11
        lblNetIncome.Text = ":"
        ' 
        ' lblNetPayResult
        ' 
        lblNetPayResult.AutoSize = True
        lblNetPayResult.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblNetPayResult.Location = New Point(384, 363)
        lblNetPayResult.Name = "lblNetPayResult"
        lblNetPayResult.Size = New Size(0, 25)
        lblNetPayResult.TabIndex = 12
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(342, 363)
        Label4.Name = "Label4"
        Label4.Size = New Size(0, 21)
        Label4.TabIndex = 13
        ' 
        ' lblNetPay
        ' 
        lblNetPay.AutoSize = True
        lblNetPay.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblNetPay.Location = New Point(205, 363)
        lblNetPay.Name = "lblNetPay"
        lblNetPay.Size = New Size(175, 21)
        lblNetPay.TabIndex = 14
        lblNetPay.Text = "Net Paycheck Income"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(684, 461)
        Controls.Add(lblNetPay)
        Controls.Add(Label4)
        Controls.Add(lblNetPayResult)
        Controls.Add(lblNetIncome)
        Controls.Add(lblFederalTax)
        Controls.Add(lblStateTax)
        Controls.Add(lblFica)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnComputeTaxes)
        Controls.Add(txtGrossPay)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(PictureBox1)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Payroll Every Two Weeks"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtGrossPay As TextBox
    Friend WithEvents btnComputeTaxes As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblFica As Label
    Friend WithEvents lblStateTax As Label
    Friend WithEvents lblFederalTax As Label
    Friend WithEvents lblNetIncome As Label
    Friend WithEvents lblNetPayResult As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblNetPay As Label

End Class
