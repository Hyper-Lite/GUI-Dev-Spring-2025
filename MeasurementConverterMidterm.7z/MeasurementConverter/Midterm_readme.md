# GUI Measurement Converter  
### Midterm Project – Spring 2025  

**Student Name:** Harold Sanders Jr 
**Course:** Spring 2025 GUI Development 
**GitHub Repository:** https://github.com/Hyper-Lite/GUI-Dev-Spring-2025  

---

Project Description  
This project is a **GUI-based Measurement Converter** developed in **Visual Basic (VB.NET)**.  
It allows users to convert between **Inches to Meters** and **Meters to Inches**, featuring:  

✔ A user-friendly interface  
✔ Input validation with error handling  
✔ Real-time conversion results  
✔ MessageBox alerts for invalid inputs  

---

Development Tools Used  
- **Visual Studio** (VB.NET)  
- **Windows Forms (WinForms)** for UI development  
- **GitHub** for version control  

---

Control Features  
1. **Radio Buttons** for selecting conversion type  
2. **Textbox Input Validation** (only accepts numbers, no negatives)  
3. **Convert Button** that calculates and displays results  
4. **Clear Button** to reset inputs  
5. **Exit Button** to close the application  
6. **MessageBox Error Handling** for:  
   - Empty input  
   - Non-numeric input  
   - Negative numbers  

---

Testing Cases & Expected Outputs  

| **Test Input** | **Expected Behavior** |
|---------------|----------------------|
| *(Empty input)* | Shows `"Please enter a value."` |
| `"ABC"` | Shows `"Invalid input. Please enter a number."` |
| `-5` | Shows `"Please enter a positive number."` |
| `5.5` | Converts correctly (e.g., `"5.5 inches is 0.140 meters."`) |
| `10` | Converts correctly (e.g., `"10 meters is 393.701 inches."`) |

---

Issues Encountered  
**None** – The development process went smoothly, and the app performs as expected.  