﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        txtInput = New TextBox()
        grpConversion = New GroupBox()
        rdoMetersToInches = New RadioButton()
        rdoInchesToMeters = New RadioButton()
        btnConvert = New Button()
        btnClear = New Button()
        btnExit = New Button()
        PictureBox1 = New PictureBox()
        lblResult = New Label()
        lblInstructions = New Label()
        grpConversion.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(295, 56)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(229, 25)
        lblTitle.TabIndex = 0
        lblTitle.Text = "Measurement Converter"
        ' 
        ' txtInput
        ' 
        txtInput.Location = New Point(368, 119)
        txtInput.Name = "txtInput"
        txtInput.Size = New Size(100, 23)
        txtInput.TabIndex = 1
        ' 
        ' grpConversion
        ' 
        grpConversion.Controls.Add(rdoMetersToInches)
        grpConversion.Controls.Add(rdoInchesToMeters)
        grpConversion.Location = New Point(317, 179)
        grpConversion.Name = "grpConversion"
        grpConversion.Size = New Size(200, 100)
        grpConversion.TabIndex = 2
        grpConversion.TabStop = False
        grpConversion.Text = "Conversion Type"
        ' 
        ' rdoMetersToInches
        ' 
        rdoMetersToInches.AutoSize = True
        rdoMetersToInches.Location = New Point(10, 63)
        rdoMetersToInches.Name = "rdoMetersToInches"
        rdoMetersToInches.Size = New Size(112, 19)
        rdoMetersToInches.TabIndex = 1
        rdoMetersToInches.TabStop = True
        rdoMetersToInches.Text = "Meters to Inches"
        rdoMetersToInches.UseVisualStyleBackColor = True
        ' 
        ' rdoInchesToMeters
        ' 
        rdoInchesToMeters.AutoSize = True
        rdoInchesToMeters.Checked = True
        rdoInchesToMeters.Location = New Point(10, 26)
        rdoInchesToMeters.Name = "rdoInchesToMeters"
        rdoInchesToMeters.Size = New Size(112, 19)
        rdoInchesToMeters.TabIndex = 0
        rdoInchesToMeters.TabStop = True
        rdoInchesToMeters.Text = "Inches to Meters"
        rdoInchesToMeters.UseVisualStyleBackColor = True
        ' 
        ' btnConvert
        ' 
        btnConvert.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnConvert.Location = New Point(102, 341)
        btnConvert.Name = "btnConvert"
        btnConvert.Size = New Size(83, 32)
        btnConvert.TabIndex = 3
        btnConvert.Text = "Convert"
        btnConvert.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnClear.Location = New Point(295, 341)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(83, 32)
        btnClear.TabIndex = 4
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnExit.Location = New Point(494, 341)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(83, 32)
        btnExit.TabIndex = 5
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.building
        PictureBox1.InitialImage = My.Resources.Resources.building
        PictureBox1.Location = New Point(12, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(277, 218)
        PictureBox1.TabIndex = 6
        PictureBox1.TabStop = False
        ' 
        ' lblResult
        ' 
        lblResult.AutoSize = True
        lblResult.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblResult.Location = New Point(331, 290)
        lblResult.Name = "lblResult"
        lblResult.Size = New Size(65, 21)
        lblResult.TabIndex = 7
        lblResult.Text = "Result: "
        lblResult.UseWaitCursor = True
        ' 
        ' lblInstructions
        ' 
        lblInstructions.AutoSize = True
        lblInstructions.Location = New Point(305, 101)
        lblInstructions.Name = "lblInstructions"
        lblInstructions.Size = New Size(219, 15)
        lblInstructions.TabIndex = 8
        lblInstructions.Text = "Enter a value and choose the conversion"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.MenuHighlight
        ClientSize = New Size(800, 450)
        Controls.Add(lblInstructions)
        Controls.Add(lblResult)
        Controls.Add(PictureBox1)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnConvert)
        Controls.Add(grpConversion)
        Controls.Add(txtInput)
        Controls.Add(lblTitle)
        Name = "Form1"
        Text = "Building Plans Conversion"
        grpConversion.ResumeLayout(False)
        grpConversion.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents grpConversion As GroupBox
    Friend WithEvents rdoInchesToMeters As RadioButton
    Friend WithEvents rdoMetersToInches As RadioButton
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblResult As Label
    Friend WithEvents lblInstructions As Label

End Class
