﻿Public Class Form1
    ' Conversion factors
    Private Const InchesToMeters As Double = 0.0254
    Private Const MetersToInches As Double = 39.3701
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblTitle.Click

    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles txtInput.TextChanged

    End Sub

    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim inputValue As Double

        ' Check if input is empty
        If txtInput.Text.Trim() = "" Then
            MessageBox.Show("Please enter a value.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtInput.Focus()
            Exit Sub
        End If

        ' Check if input is numeric
        If Not Double.TryParse(txtInput.Text, inputValue) Then
            MessageBox.Show("Invalid input. Please enter a number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtInput.Clear()
            txtInput.Focus()
            Exit Sub
        End If

        ' Check if input is negative
        If inputValue < 0 Then
            MessageBox.Show("Please enter a positive number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtInput.Clear()
            txtInput.Focus()
            Exit Sub
        End If

        ' Perform conversion
        Dim result As Double
        If rdoInchesToMeters.Checked Then
            result = inputValue * InchesToMeters
            lblResult.Text = $"{inputValue} inches is {Math.Round(result, 3)} meters."
        Else
            result = inputValue * MetersToInches
            lblResult.Text = $"{inputValue} meters is {Math.Round(result, 3)} inches."
        End If

        btnClear.Enabled = True ' Enable Clear button after conversion
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtInput.Clear()
        lblResult.Text = ""
        rdoInchesToMeters.Checked = True
        txtInput.Focus()
        btnClear.Enabled = False ' Disable clear button after clearing
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles lblInstructions.Click

    End Sub
End Class
