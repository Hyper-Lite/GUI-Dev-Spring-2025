﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_P1___Harold_S_Jr
{
    public partial class FrnchNum : Form
    {
        public FrnchNum()
        {
            InitializeComponent();
        }

        private void lblFrench_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close(); // Closes the form
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lblFrench.Text = "Trois"; // Displays "Trois" when btnThree is clicked
            lblFrench.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblFrench.Text = "Un"; // Displays "Un" when btnOne is clicked
            lblFrench.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblFrench.Text = "Deux"; // Displays "Deux" when btnTwo is clicked
            lblFrench.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lblFrench.Text = "Quatre"; // Displays "Quatre" when btnFour is clicked
            lblFrench.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lblFrench.Text = "Cinq"; // Displays "Cinq" when btnFive is clicked
            lblFrench.Visible = true;
        }

        private void FrnchNum_Load(object sender, EventArgs e)
        {

        }
    }
}
