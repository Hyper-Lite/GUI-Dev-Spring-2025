﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        btnDisplayStats = New Button()
        cboMonths = New ComboBox()
        PictureBox1 = New PictureBox()
        lblMaxMonth = New Label()
        lblAverage = New Label()
        lblMonthlySavings = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(394, 73)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(228, 21)
        lblTitle.TabIndex = 0
        lblTitle.Text = "Smart Home Electric Savings"
        lblTitle.TextAlign = ContentAlignment.TopCenter
        ' 
        ' btnDisplayStats
        ' 
        btnDisplayStats.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnDisplayStats.Location = New Point(422, 248)
        btnDisplayStats.Name = "btnDisplayStats"
        btnDisplayStats.Size = New Size(181, 40)
        btnDisplayStats.TabIndex = 3
        btnDisplayStats.Text = "Display Statistics"
        btnDisplayStats.UseVisualStyleBackColor = True
        ' 
        ' cboMonths
        ' 
        cboMonths.FormattingEnabled = True
        cboMonths.Location = New Point(417, 127)
        cboMonths.Name = "cboMonths"
        cboMonths.Size = New Size(142, 23)
        cboMonths.TabIndex = 4
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.smarthome
        PictureBox1.Location = New Point(16, 42)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(376, 262)
        PictureBox1.TabIndex = 5
        PictureBox1.TabStop = False
        ' 
        ' lblMaxMonth
        ' 
        lblMaxMonth.AutoSize = True
        lblMaxMonth.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMaxMonth.Location = New Point(438, 216)
        lblMaxMonth.Name = "lblMaxMonth"
        lblMaxMonth.Size = New Size(0, 17)
        lblMaxMonth.TabIndex = 9
        ' 
        ' lblAverage
        ' 
        lblAverage.AutoSize = True
        lblAverage.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAverage.Location = New Point(438, 192)
        lblAverage.Name = "lblAverage"
        lblAverage.Size = New Size(0, 17)
        lblAverage.TabIndex = 10
        ' 
        ' lblMonthlySavings
        ' 
        lblMonthlySavings.AutoSize = True
        lblMonthlySavings.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMonthlySavings.Location = New Point(438, 166)
        lblMonthlySavings.Name = "lblMonthlySavings"
        lblMonthlySavings.Size = New Size(0, 17)
        lblMonthlySavings.TabIndex = 11
        ' 
        ' frmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lblMonthlySavings)
        Controls.Add(lblAverage)
        Controls.Add(lblMaxMonth)
        Controls.Add(PictureBox1)
        Controls.Add(cboMonths)
        Controls.Add(btnDisplayStats)
        Controls.Add(lblTitle)
        Name = "frmMain"
        Text = "Smart Home Application"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents btnDisplayStats As Button
    Friend WithEvents cboMonths As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblMaxMonth As Label
    Friend WithEvents lblAverage As Label
    Friend WithEvents lblMonthlySavings As Label
    Friend WithEvents Label8 As Label

End Class
