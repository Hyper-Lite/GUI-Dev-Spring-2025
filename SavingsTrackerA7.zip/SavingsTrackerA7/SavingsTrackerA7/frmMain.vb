﻿Public Class frmMain

    ' Store months and savings separately
    Dim months As New List(Of String)
    Dim savings As New List(Of Decimal)

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Read file and fill lists
        Dim lines() As String = IO.File.ReadAllLines("savings.txt")

        For Each line In lines
            Dim parts() As String = line.Split(","c)
            months.Add(parts(0))
            savings.Add(Convert.ToDecimal(parts(1)))
        Next

        ' Populate combo box with month names
        cboMonths.Items.AddRange(months.ToArray())
    End Sub

    Private Sub cboMonths_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMonths.SelectedIndexChanged
        Dim index As Integer = cboMonths.SelectedIndex
        If index >= 0 Then
            lblMonthlySavings.Text = $"The electric savings for {months(index)} is {savings(index):C2}"
        End If
    End Sub

    Private Sub btnDisplayStats_Click(sender As Object, e As EventArgs) Handles btnDisplayStats.Click
        If savings.Count = 0 Then Return

        ' Calculate average
        Dim avg As Decimal = savings.Average()
        lblAverage.Text = $"The average monthly savings: {avg:C2}"

        ' Find max and its index
        Dim maxValue As Decimal = savings.Max()
        Dim maxIndex As Integer = savings.IndexOf(maxValue)
        Dim maxMonth As String = months(maxIndex)

        lblMaxMonth.Text = $"{maxMonth} had the most significant monthly savings"
    End Sub

End Class