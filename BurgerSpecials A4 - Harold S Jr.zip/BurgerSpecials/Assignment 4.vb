﻿Public Class frmBurgers
    ' Event handler for form load event
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Set initial control states
        picPrime.Visible = False
        picVeggie.Visible = False
        lblConfirmation.Visible = False
        btnSelectMeal.Enabled = False
        btnExit.Enabled = False
    End Sub

    ' Event handler for Select Meal button click
    Private Sub btnSelectMeal_Click(sender As Object, e As EventArgs) Handles btnSelectMeal.Click
        ' Display confirmation message
        lblConfirmation.Visible = True

        ' Disable meal selection buttons to prevent further changes
        Button2.Enabled = False
        Button1.Enabled = False

        ' Disable Select Meal button to lock in the selection
        btnSelectMeal.Enabled = False

        ' Enable Exit button so the user can leave
        btnExit.Enabled = True
    End Sub


    ' Event handler for Veggie picture box click (not required for functionality)
    Private Sub picVeggie_Click(sender As Object, e As EventArgs) Handles picVeggie.Click
        ' No action needed
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        picPrime.Visible = True
        picVeggie.Visible = False
        btnSelectMeal.Enabled = True
        btnExit.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        picVeggie.Visible = True
        picPrime.Visible = False
        btnSelectMeal.Enabled = True
        btnExit.Visible = True
    End Sub
    'Event handler for exit button
    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        ' Close the application
        Close()
    End Sub

    Private Sub btnExit_Click_1(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close the application
        Close()
    End Sub
End Class
